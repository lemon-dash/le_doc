1. LogisticRegression

2. AdaBoost

3. XGBoost

4. 随机森林

5. 决策树

6. 支持向量机(SVM)

7. GRU

8. 1D CNN

9. 全连接神经网络 FNN

