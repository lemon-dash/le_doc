# -*- coding: utf-8 -*-
"""
Created on Sat Sep  9 19:08:44 2023

@author: Caesar
"""

import pandas as pd
import matplotlib.pyplot as plt

# 从CSV文件中读取数据
pred_test = pd.read_csv('pred_test.csv', header=None)
true_test = pd.read_csv('true_test.csv', header=None)

# 假设你的CSV文件包含两列：'x'和'y'，你可以根据实际情况修改列名
x = pred_test
y = true_test

# 绘制折线图
plt.figure(figsize=(10, 6))  # 设置图形大小
plt.plot(pred_test, label='pred_test', marker='o', linestyle='-')
plt.plot(true_test, label='true_test', marker='x', linestyle='--')
plt.xlabel('')  # 设置X轴标签
plt.ylabel('VHT')  # 设置Y轴标签
plt.title('contrast between pred_value and true_value')  # 设置图表标题
plt.legend()  # 显示图例
plt.grid(True)  # 添加网格线
plt.show()  # 显示图

pred_all = pd.read_csv('pred_all.csv', header=None)
true_all = pd.read_csv('true_all.csv', header=None)

# 假设你的CSV文件包含两列：'x'和'y'，你可以根据实际情况修改列名
x = pred_all
y = true_all

# 绘制折线图
plt.figure(figsize=(25, 6))  # 设置图形大小
plt.plot(pred_test, label='pred', marker='o', linestyle='-')
plt.plot(true_test, label='true', marker='x', linestyle='--')
plt.xlabel('')  # 设置X轴标签
plt.ylabel('VHT')  # 设置Y轴标签
plt.title('contrast between pred_value and true_value')  # 设置图表标题
plt.legend()  # 显示图例
plt.grid(True)  # 添加网格线
plt.show()  # 显示图