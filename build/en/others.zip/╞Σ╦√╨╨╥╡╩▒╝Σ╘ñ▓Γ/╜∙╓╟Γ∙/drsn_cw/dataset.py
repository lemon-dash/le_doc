# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 18:26:20 2023

@author: Caesar
"""
from sklearn.preprocessing import MinMaxScaler
import torch 
from torch.utils.data import Dataset

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split


DataPath='D:/Study/论文/数据收集/数据处理/data/'# 输入数据

# 导入数据集
data_list = ['features_teu.csv', 'features_vessel.csv', 'features_port.csv', 'features_weather.csv']

random_seed = 42
test_size = 0.2
max_features = 15
val_frac=0.2

def pad_features(data, max_features):#pad features with 0
    num_samples, num_features = data.shape
    padding = max_features - num_features
    padded_data = np.pad(data, ((0, 0), (0, padding)), mode='constant')
    return padded_data

scaler = MinMaxScaler()  # Initialize MinMaxScaler
x_data = []
for data in data_list:
    df = pd.read_csv(DataPath+data)
    data = df.to_numpy()
    padded_data = pad_features(data, max_features)  # Pad features
    scaled_data = scaler.fit_transform(padded_data)  # Scale data
    x_data.append(scaled_data)
x_data = np.stack(x_data, axis=1)  # Stack data along the channel dimension
x_data = torch.tensor(x_data, dtype=torch.float32)#type convert

y_data = pd.read_csv(DataPath + 'targets.csv').to_numpy()

x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=random_seed)

x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.2, random_state=random_seed)

class VVDataset(Dataset):
    def __init__(self,x_data,y_data):
        self.x_data = x_data
        self.y_data = y_data
        self.len = self.x_data.shape[0]

    def __getitem__(self, index):
        return self.x_data[index], self.y_data[index]
    def __len__(self):
        return self.len
    

train_set = VVDataset(x_train, y_train)
test_set = VVDataset(x_test, y_test)
val_set = VVDataset(x_val, y_val)
