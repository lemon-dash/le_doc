# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 17:53:40 2023

@author: Caesar
"""
import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
import senet
import dataset
from torch.utils.data import DataLoader
import numpy as np
from scipy.stats import pearsonr
from torch.utils.tensorboard import SummaryWriter
import time

current_time = time.strftime("%Y-%m-%dT%H：%M", time.localtime())

model = senet.rsnet18()

learning_rate = 1e-3
training_epochs = 200
batch_size = 99
initial_patience = 50
Path='D:/Study/论文/模型/torch/senet/'

writer = SummaryWriter(log_dir = Path+"data/"+current_time)

# 创建一个随机梯度下降（stochastic gradient descent）优化器
optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=0.89)
# 创建一个损失函数
criterion = nn.L1Loss(size_average=True)

train_loader = DataLoader(dataset.train_set, batch_size = batch_size, shuffle = True)
test_loader = DataLoader(dataset.test_set, batch_size = len(dataset.test_set), shuffle = False)
val_loader = DataLoader(dataset.val_set, batch_size = batch_size, shuffle = True)

if __name__=='__main__':
    best_metric = float('inf')  # Initialize with a large value
    patience = initial_patience  # Initialize patience for early stopping
    for epoch in range(training_epochs):

        model.train()

        for index, data in enumerate(train_loader,0):

            x, y = data # prepare data
            y_pred = model(x)# Forward pass
            loss = criterion(y_pred,y)# Calculate loss
            optimizer.zero_grad()  # Clear gradients
            loss.backward()  # Backpropagation
            
            # nn.utils.clip_grad_norm_(model.parameters(), 2, norm_type=2)
            
            # for name, param in model.conv3_x.named_parameters():
            #     if param.grad is not None:
            #         print(f"Parameter: {name}, Gradient: {param.grad.norm()}")  # Print gradient norm
        
            
            
            
            optimizer.step()  # Update model parameters
            
            # writer.add_scalar('Loss/train', loss.item(), epoch)  # Replace current_epoch with the actual epoch number
            writer.add_scalar('Loss/train', loss.item(), epoch * len(train_loader) + index)
            print(f"Epoch [{epoch+1}/{training_epochs}], Loss: {loss.item():.4f}")
         


        model.eval()
        with torch.no_grad():
            val_loss = 0.0
            for index, data in enumerate(val_loader,0):
                x, y = data
                y_pred = model(x)
                loss = criterion(y_pred, y)
                val_loss+= loss.item()
                
                writer.add_scalar('Loss/validation', loss.item(), epoch * len(val_loader) + index)

            # Calculate average validation loss
            val_loss /= len(val_loader)
            print(f"Epoch [{epoch + 1}/{training_epochs}], Val_Loss: {val_loss:.4f}")

        # Check if the current metric is better than the best
        if val_loss < best_metric:
            best_metric = val_loss
            best_epoch = epoch
            # Save the model checkpoint
            torch.save(model.state_dict(), 'best_model.pth')
        else:
            # If metric hasn't improved, increment patience
            patience -= 1
            if patience == 0:
                print(f"Early stopping triggered. Best Validation Loss at epoch {best_epoch}.")
                break
            
            
        writer.close()
    
    
    model.eval()
    # pred_test = []
    # true_test = []
    with torch.no_grad():
        test_loss = 0.0
        for index, data in enumerate(test_loader,0):
            x_batch, y_batch = data 
            pred_test = model(x_batch).numpy()
            true_test = y_batch.numpy()

            # Calculate average validation loss
        test_loss /= len(test_loader)


    with torch.no_grad():
        pred_train = []
        true_train = []
        for index, data in enumerate(train_loader,0):
            x_batch, y_batch = data 
            
            batch_pred = model(x_batch).numpy()
            batch_true = y_batch.numpy()
            
            pred_train.append(batch_pred)
            true_train.append(batch_true)

        pred_train = np.vstack(pred_train)
        true_train = np.vstack(true_train) 
            
          
    with torch.no_grad():
      for index, data in enumerate(val_loader,0):
          x_batch, y_batch = data 
          pred_val = model(x_batch).numpy()
          true_val = y_batch.numpy()      


    pred_all = np.concatenate((pred_train, pred_val, pred_test), axis = 0)
    true_all = np.concatenate((true_train, true_val, true_test), axis = 0)




    # Calculate R2 score and Pearson correlation coefficient for test set
    mean_true_test = np.mean(true_test)
    sst_test = np.sum((true_test - mean_true_test) ** 2)
    ssr_test = np.sum((pred_test - true_test) ** 2)
    r2_test = 1 - (ssr_test / sst_test)
   
    mae_test = np.mean(np.abs(pred_test - true_test))
    mape_test = np.mean(np.abs((pred_test - true_test)/true_test))
    mse_test = np.mean((pred_test - true_test) ** 2)
    pearson_r_test, _ = pearsonr(pred_test.flatten(), true_test.flatten())
    
    # print(f"Test Loss: {test_loss:.4f}")

    print("Test Set MAE:", mae_test)
    print("Test Set MAPE:{:.4%}". format(mape_test))
    print("Test Set MSE:", mse_test)

    print("Test Set R2 score:", r2_test)
    print("Test Set Pearson correlation coefficient:", pearson_r_test)
    
    np.savetxt('pred_test.csv', pred_test, delimiter=',')
    np.savetxt('true_test.csv', true_test, delimiter=',')
    
    
    mean_true_all = np.mean(true_all)
    sst_all = np.sum((true_all - mean_true_all) ** 2)
    ssr_all = np.sum((pred_all - true_all) ** 2)
    r2_all = 1 - (ssr_all / sst_all)
   
    mae_all = np.mean(np.abs(pred_all - true_all))
    mape_all = np.mean(np.abs((pred_all - true_all)/true_all))
    mse_all = np.mean((pred_all - true_all) ** 2)
    pearson_r_all, _ = pearsonr(pred_all.flatten(), true_all.flatten())
    
    
    
    
    # print(f"All Loss: {All_loss:.4f}")

    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

    print("All Set MAE:", mae_all)
    print("All Set MAPE:{:.4%}". format(mape_all))
    print("All Set MSE:", mse_all)

    print("All Set R2 score:", r2_all)
    print("All Set Pearson correlation coefficient:", pearson_r_all)
    
    np.savetxt('pred_all.csv', pred_all, delimiter=',')
    np.savetxt('true_all.csv', true_all, delimiter=',')
    
    
    
    