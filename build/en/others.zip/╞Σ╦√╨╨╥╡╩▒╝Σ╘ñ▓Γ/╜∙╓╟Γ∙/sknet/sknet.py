# -*- coding: utf-8 -*-
"""
Created on Sat Apr 13 15:46:16 2024

@author: Caesar
"""

import torch
import torch.nn as nn
from functools import reduce

class SKConv(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, M=2, r=1, L=32):
        super(SKConv, self).__init__()
        
        # 计算特征Z的长度d
        d = max(in_channels // r, L)
        self.M = M
        self.out_channels = out_channels
        self.conv3 = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.conv5 = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=2, bias=False),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(inplace=True)
        )
        
        # 全局平均池化层，用于将特征降维到1维
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        
        # 降维全连接层fc1和升维全连接层fc2
        self.fc1 = nn.Sequential(
            nn.Conv1d(out_channels, d, kernel_size=1, bias=False),
            nn.BatchNorm1d(d),
            nn.ReLU(inplace=True)
        )
        self.fc2 = nn.Conv1d(d, out_channels * M * 2, kernel_size=1, stride=1, bias=False)
        
        # Softmax层，用于计算不同分支的权重
        self.softmax = nn.Softmax(dim=1)

    def forward(self, input):
        batch_size = input.size(0)
        # in_channels = input.size(1)
        # M = 2
        output = []
        
        # 计算卷积核大小为3的分支的输出
        output.append(self.conv3(input))
        
        # 计算卷积核大小为5的分支的输出
        output.append(self.conv5(input))
        
        # 将所有分支的输出堆叠在一起
        U = reduce(lambda x, y: x+y, output)
        U = self.global_pool(U)
        
        
        
        
        # U = torch.stack(output, dim=1)
        # # U = torch.sum(U, dim = 1)# 求和
        
        # U = U.view(batch_size * M, in_channels, -1)
        # # 全局平均池化，将特征降维到1维
        # U = self.global_pool(U)
        # U = U.view(batch_size, M, in_channels, 1)
        
        
        # U = U.squeeze(-1)
        
        # 经过fc1降维
        S = self.fc1(U)
        
        # 经过fc2升维
        A = self.fc2(S)
        # A = A.reshape(batch_size, self.M * 2, self.out_channels, -1)
        
        # # 计算分支的权重
        # A = self.softmax(A)
        
        # # 对每个分支的输出进行加权求和
        # A = list(A.chunk(self.M * 2, dim=1))
        # A = list(map(lambda x: x.reshape(batch_size, self.out_channels, 1, 1), A))
        # V = list(map(lambda x, y: x * y, output, A))
        # V = torch.stack(V, dim=1)
        # V = V.sum(dim=1)
        
        A = A.reshape(batch_size, self.M, self.out_channels, -1) # reshape 为两个 FCs 的值
        A=self.softmax(A)  # 令两个 FCs 对应位置进行 softmax
        
        
        #the part of selection
        A=list(A.chunk(self.M, dim=1))  # split to a 和 b - chunk 将 tensor 按指定维度切分成几块
        A=list(map(lambda x: x.reshape(batch_size, self.out_channels, 1, 1), A))  # reshape 所有分块，即扩展两维
        V=list(map(lambda x, y: x*y, output, A)) # 权重与对应不同卷积核输出的 U 逐元素相乘
        V=reduce(lambda x, y: x+y, V)  # 两个加权后的特征 逐元素相加

        
        
        
        return V


class SKBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(SKBlock, self).__init__()
        
        # 第一个卷积层，3x3卷积，BN，ReLU
        self.conv1 = nn.Conv1d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(planes)
        self.relu = nn.ReLU(inplace=True)
        
        # SKConv模块，多分支卷积
        self.conv2 = SKConv(planes, planes, stride=stride)
        
        # 下采样层，如果输入输出通道数不同，则使用1x1卷积进行下采样
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        # 第一个卷积层
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # SKConv模块
        out = self.conv2(out)

        # 下采样
        if self.downsample is not None:
            identity = self.downsample(x)

        # 残差连接
        out += identity
        out = self.relu(out)

        return out

class SKNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=1):
        super(SKNet, self).__init__()
        self.inplanes = 64
        
        # 输入层，7x7卷积，BN，ReLU
        self.conv1 = nn.Conv1d(4, 64, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(64)
        self.relu = nn.ReLU(inplace=True)
        
        # 最大池化层
        self.maxpool = nn.MaxPool1d(kernel_size=4, stride=2, padding=1)
        
        # 四个SKBlock组成的网络层
        self.layer1 = self._make_layer(block, 64, num_blocks[0])
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        
        # 全局平均池化层
        self.avgpool = nn.AdaptiveAvgPool1d(1)
        
        # 全连接层，输出类别数
        self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')

    def _make_layer(self, block, planes, num_blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv1d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm1d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for _ in range(1, num_blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)
        
        
        # strides = [stride] + [1] * (num_blocks - 1)
        # layers = []
        # for stride in strides:
        #     layers.append(block(self.inplanes, planes, stride))
        #     self.inplanes = planes * block.expansion

        # return nn.Sequential(*layers)
        

    def forward(self, x):
        # 输入层
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        
        # 最大池化
        # x = self.maxpool(x)

        # 四个SKBlock
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        # 全局平均池化
        x = self.avgpool(x)
        
        # 展平
        x = x.view(x.size(0), -1)
        
        # 全连接层
        x = self.fc(x)

        return x

def SKNet18():
    return SKNet(SKBlock, [2, 2, 2, 2])


