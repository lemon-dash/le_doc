# -*- coding: utf-8 -*-
"""
Created on Sat Sep  9 19:08:44 2023

@author: Caesar
"""

import pandas as pd
import matplotlib.pyplot as plt

RANDSEED = 625
FRAC = 0.9

# 从CSV文件中读取数据
pred_test = pd.read_csv('pred_test.csv', header=None)
true_test = pd.read_csv('true_test.csv', header=None)

df1 = pd.concat([pred_test, true_test], axis=1)
df1 = df1.sample(frac=FRAC, random_state=RANDSEED)
df1.reset_index(drop=True, inplace=True)


# 假设你的CSV文件包含两列：'x'和'y'，你可以根据实际情况修改列名
# x1 = pred_test.sample(n=None, frac=0.8, replace=False, weights=None, random_state=RANDSEED, axis=0)
# y1 = true_test.sample(n=None, frac=0.8, replace=False, weights=None, random_state=RANDSEED, axis=0)

num_columns1 = len(pred_test.columns)
x1 = df1.iloc[:, :num_columns1]
y1 = df1.iloc[:, num_columns1:]


# 绘制折线图
plt.figure(figsize=(10, 6))  # 设置图形大小
plt.plot(x1, label='pred_test', marker='o', linestyle='-')
plt.plot(y1, label='true_test', marker='x', linestyle='--')
plt.xlabel('')  # 设置X轴标签
plt.ylabel('VHT')  # 设置Y轴标签
plt.title('contrast between pred_value and true_value')  # 设置图表标题
plt.legend()  # 显示图例
plt.grid(True)  # 添加网格线
plt.show()  # 显示图

pred_all = pd.read_csv('pred_all.csv', header=None)
true_all = pd.read_csv('true_all.csv', header=None)

# 假设你的CSV文件包含两列：'x'和'y'，你可以根据实际情况修改列名
# x2 = pred_all.sample(n=None, frac=0.8, replace=False, weights=None, random_state=RANDSEED, axis=0)
# y2 = true_all.sample(n=None, frac=0.8, replace=False, weights=None, random_state=RANDSEED, axis=0)

df2 = pd.concat([pred_all, true_all], axis=1)
df2 = df2.sample(frac=FRAC, random_state=RANDSEED)
df2.reset_index(drop=True, inplace=True)


num_columns2 = len(pred_all.columns)
x2 = df2.iloc[:, :num_columns2]
y2 = df2.iloc[:, num_columns2:]



# 绘制折线图
plt.figure(figsize=(40, 10))  # 设置图形大小
plt.plot(x2, label='pred', marker='o', linestyle='-')
plt.plot(y2, label='true', marker='x', linestyle='--')
plt.xlabel('')  # 设置X轴标签
plt.ylabel('VHT')  # 设置Y轴标签
plt.title('contrast between pred_value and true_value')  # 设置图表标题
plt.legend()  # 显示图例
plt.grid(True)  # 添加网格线
plt.xlim(0, 450)
plt.tight_layout()
plt.show()  # 显示图