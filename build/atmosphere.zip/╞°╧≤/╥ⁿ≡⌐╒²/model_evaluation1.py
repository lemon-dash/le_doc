from sklearn.metrics import classification_report, accuracy_score
import numpy as np


def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    # 如果 y_pred 是多维数组（例如，概率分布），则取最大值的索引
    if len(y_pred.shape) > 1:
        y_pred = np.argmax(y_pred, axis=1)

    # 确保 y_test 和 y_pred 长度一致
    if len(y_test) != len(y_pred):
        raise ValueError(f"Length of y_test: {len(y_test)} does not match length of y_pred: {len(y_pred)}")

    report = classification_report(y_test, y_pred, target_names=['rain', 'fog', 'snow'], output_dict=True)

    overall_accuracy = report['accuracy']
    weather_accuracies = {weather: report[weather]['precision'] for weather in ['rain', 'fog', 'snow']}

    return overall_accuracy, weather_accuracies