import numpy as np
import os
import csv
import json
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam

# 定义全局变量
data_dir = 'dataset/train'  # 替换为你的数据集路径
img_height, img_width = 128, 128
batch_size = 32
model_path = 'cnn_weather_model.h5'
history_file = 'cnn_training_history.csv'
csv_report_file = 'cnn_classification_report.csv'
accuracy_file = 'cnn_per_class_accuracy.csv'

# 1. 数据加载与预处理
def load_data(data_dir, img_height, img_width, batch_size):
    # 选择要分类的类别，忽略 'sleet' 类别
    selected_classes = ['rain', 'fog', 'snow']  # 只选择这三个类别

    datagen = ImageDataGenerator(rescale=1. / 255, validation_split=0.3)

    train_generator = datagen.flow_from_directory(
        data_dir,
        target_size=(img_height, img_width),
        batch_size=batch_size,
        class_mode='categorical',
        classes=selected_classes,  # 仅选择三个类别，忽略 'sleet'
        subset='training'
    )

    validation_generator = datagen.flow_from_directory(
        data_dir,
        target_size=(img_height, img_width),
        batch_size=batch_size,
        class_mode='categorical',
        classes=selected_classes,  # 仅选择三个类别，忽略 'sleet'
        subset='validation'
    )

    return train_generator, validation_generator


# 2. 创建或加载模型
def create_or_load_model(model_path, input_shape, num_classes):
    if os.path.exists(model_path):
        print("加载已保存的模型...")
        return load_model(model_path)

    print("创建新模型...")
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])
    return model


# 3. 训练模型并保存历史记录
def train_and_save_model(model, train_generator, validation_generator, model_path, history_file, epochs=10):
    history = model.fit(train_generator, validation_data=validation_generator, epochs=epochs)
    model.save(model_path)

    # 保存训练历史
    with open(history_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Epoch', 'Train Accuracy', 'Validation Accuracy', 'Train Loss', 'Validation Loss'])
        for epoch in range(len(history.history['accuracy'])):
            writer.writerow([epoch + 1,
                             history.history['accuracy'][epoch],
                             history.history['val_accuracy'][epoch],
                             history.history['loss'][epoch],
                             history.history['val_loss'][epoch]])

    return history


# 4. 模型评估与保存结果
def evaluate_and_save_results(model, validation_generator, csv_report_file, accuracy_file):
    validation_generator.reset()
    y_pred = model.predict(validation_generator)
    y_pred_classes = np.argmax(y_pred, axis=1)
    y_true = validation_generator.classes

    class_labels = list(validation_generator.class_indices.keys())

    # 分类报告
    report = classification_report(y_true, y_pred_classes, target_names=class_labels, output_dict=True)
    with open(csv_report_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Class', 'Precision', 'Recall', 'F1-Score', 'Support'])
        for label, metrics in report.items():
            if isinstance(metrics, dict):
                writer.writerow(
                    [label, metrics['precision'], metrics['recall'], metrics['f1-score'], metrics['support']])

    # 打印和保存每类的准确率
    conf_matrix = confusion_matrix(y_true, y_pred_classes)
    conf_matrix_normalized = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]
    with open(accuracy_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Class', 'Accuracy'])
        for i, label in enumerate(class_labels):
            writer.writerow([label, conf_matrix_normalized[i, i]])

    return class_labels, conf_matrix_normalized


# 5. 可视化训练历史
def plot_training_history(history):
    plt.figure(figsize=(8, 6))
    plt.plot(history.history['accuracy'], label='Train Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()

    plt.figure(figsize=(8, 6))
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()


# 6. 可视化混淆矩阵
def plot_confusion_matrix(conf_matrix_normalized, class_labels):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix_normalized, annot=True, cmap='Blues', xticklabels=class_labels, yticklabels=class_labels,
                fmt=".2f")
    plt.title('Normalized Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()


# 主流程
train_generator, validation_generator = load_data(data_dir, img_height, img_width, batch_size)
model = create_or_load_model(model_path, (img_height, img_width, 3), 3)  # 将类别数修改为 3

if not os.path.exists(model_path):  # 只在模型不存在时训练
    history = train_and_save_model(model, train_generator, validation_generator, model_path, history_file)
    plot_training_history(history)

class_labels, conf_matrix_normalized = evaluate_and_save_results(model, validation_generator, csv_report_file,
                                                                 accuracy_file)
plot_confusion_matrix(conf_matrix_normalized, class_labels)
