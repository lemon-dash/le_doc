import numpy as np
from sklearn.model_selection import train_test_split
import cv2
import os

def load_data(image_dir, image_size=(128, 128)):
    images = []
    labels = []
    for label in os.listdir(image_dir):
        for file in os.listdir(os.path.join(image_dir, label)):
            img = cv2.imread(os.path.join(image_dir, label, file))
            img = cv2.resize(img, image_size)
            images.append(img)
            labels.append(label)
    images = np.array(images)
    labels = np.array(labels)
    return images, labels

def preprocess_data(images, labels):
    images = images.astype('float32') / 255.0
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    labels = le.fit_transform(labels)
    return images, labels

def flatten_images(images):
    num_samples = images.shape[0]
    height = images.shape[1]
    width = images.shape[2]
    channels = images.shape[3]
    flattened_images = images.reshape(num_samples, height * width * channels)
    return flattened_images