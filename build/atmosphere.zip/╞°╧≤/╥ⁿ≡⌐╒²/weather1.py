import numpy as np
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.ensemble import VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Flatten, Dense
from tensorflow.keras.layers import Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint

# 1. 数据加载与预处理
data_dir = 'dataset/train'  # 替换为你的数据集路径
img_height, img_width = 128, 128  # 调整图像大小
batch_size = 8

datagen = ImageDataGenerator(rescale=1./255, validation_split=0.3)

train_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='training'
)

validation_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation'
)

# 提取特征向量
def extract_features(generator, model):
    features = []
    labels = []
    for i in range(len(generator)):
        x, y = generator[i]
        feature = model.predict(x)
        features.append(feature)
        labels.append(y)

    # 将所有批次的特征和标签堆叠在一起
    features = np.vstack(features)
    labels = np.vstack(labels)

    return features, labels

# 使用预训练的VGG16模型提取特征
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
model = Model(inputs=base_model.input, outputs=Flatten()(base_model.output))

# 添加全连接层和自定义神经网络结构
x = Flatten()(base_model.output)
x = Dense(128, activation='relu')(x)
x = Dropout(0.5)(x)
output = Dense(len(train_generator.class_indices), activation='softmax')(x)

# 构建完整的神经网络模型
cnn_model = Model(inputs=base_model.input, outputs=output)

# 冻结VGG16的卷积层
for layer in base_model.layers:
    layer.trainable = False

# 编译神经网络模型
cnn_model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

# 设置回调保存最好的模型
checkpoint = ModelCheckpoint('best_model.h5', monitor='val_accuracy', save_best_only=True, mode='max', verbose=1)

# 训练神经网络并记录训练过程
history = cnn_model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=10,  # 你可以根据需要调整
    callbacks=[checkpoint]
)

# 训练完成后，将 accuracy 和 loss 变化趋势可视化
# plt.figure(figsize=(10, 7))
# plt.plot(history.history['accuracy'], label='Train Accuracy')
# plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
# plt.title('Training and Validation Accuracy')
# plt.xlabel('Epoch')
# plt.ylabel('Accuracy')
# plt.legend()
# plt.show()
#
# plt.figure(figsize=(10, 7))
# plt.plot(history.history['loss'], label='Train Loss')
# plt.plot(history.history['val_loss'], label='Validation Loss')
# plt.title('Training and Validation Loss')
# plt.xlabel('Epoch')
# plt.ylabel('Loss')
# plt.legend()
# plt.show()

# 提取训练和验证特征
X_train, y_train = extract_features(train_generator, model)
X_test, y_test = extract_features(validation_generator, model)

# 2. 模型选择
# 定义多个模型
models = [
    ('lr', LogisticRegression(max_iter=1000)),
    ('svm', SVC(probability=True)),
    ('rf', RandomForestClassifier()),
    ('knn', KNeighborsClassifier()),
    ('dt', DecisionTreeClassifier()),
    ('nb', GaussianNB()),
    ('mlp', MLPClassifier(max_iter=1000))
]

# 3. 集成模型
# 使用VotingClassifier进行模型集成
ensemble_model = VotingClassifier(estimators=models, voting='soft')
ensemble_model.fit(X_train, np.argmax(y_train, axis=1))

# 获取类标签的名称（四种天气类型）
class_labels = list(train_generator.class_indices.keys())

# 评估集成模型
ensemble_model = VotingClassifier(estimators=models, voting='soft')
ensemble_model.fit(X_train, np.argmax(y_train, axis=1))

# 4. 模型评估
# 预测并评估性能
y_pred = ensemble_model.predict(X_test)
y_true = np.argmax(y_test, axis=1)

print("Classification report of integrated models:\n", classification_report(y_true, y_pred, target_names=class_labels))
print("Accuracy of integrated models: ", accuracy_score(y_true, y_pred))

# 5. 显示每种天气的准确率
conf_matrix = confusion_matrix(y_true, y_pred)
conf_matrix_normalized = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]
per_class_accuracy = np.diag(conf_matrix_normalized)
print("Accuracy for each type of weather: ", per_class_accuracy)

# 6. 仿真图
# 混淆矩阵可视化
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix_normalized, annot=True, cmap='Blues', xticklabels=train_generator.class_indices.keys(), yticklabels=train_generator.class_indices.keys(), fmt=".2f")
plt.title('Normalized Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# 显示每种天气的准确率
plt.figure(figsize=(10, 7))
class_labels = list(train_generator.class_indices.keys())
plt.bar(class_labels, per_class_accuracy)
plt.title('Per-class Accuracy')
plt.xlabel('Weather Type')
plt.ylabel('Accuracy')
plt.show()

# 显示训练和验证准确率的变化趋势
plt.figure(figsize=(10, 7))
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

# 显示训练和验证损失的变化趋势
plt.figure(figsize=(10, 7))
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()
