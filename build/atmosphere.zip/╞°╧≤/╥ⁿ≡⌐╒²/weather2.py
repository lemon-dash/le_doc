import numpy as np
import pandas as pd
import os
import csv
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.applications import VGG16
from tensorflow.keras.callbacks import ModelCheckpoint

# 定义全局变量
data_dir = 'dataset/train'  # 替换为你的数据集路径
img_height, img_width = 128, 128  # 调整图像大小
batch_size = 8

# 忽略 'sleet' 类别
selected_classes = ['rain', 'fog', 'snow']

datagen = ImageDataGenerator(rescale=1./255, validation_split=0.3)

train_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    classes=selected_classes,  # 只选择三个类别
    subset='training'
)

validation_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    classes=selected_classes,  # 只选择三个类别
    subset='validation'
)

# 使用预训练的VGG16模型
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
x = Flatten()(base_model.output)
x = Dense(128, activation='relu')(x)
x = Dropout(0.5)(x)
output = Dense(len(selected_classes), activation='softmax')(x)

cnn_model = Model(inputs=base_model.input, outputs=output)
for layer in base_model.layers:
    layer.trainable = False

cnn_model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

checkpoint = ModelCheckpoint('best_model.h5', monitor='val_accuracy', save_best_only=True, mode='max', verbose=1)

history = cnn_model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=10,  # 根据需要调整
    callbacks=[checkpoint]
)

# 保存历史数据到CSV
history_df = pd.DataFrame(history.history)
history_df.to_csv('training_history.csv', index=False)

# 提取特征，训练集成模型
# ...省略集成模型的代码，根据之前的示例自行添加

# 评估模型
y_pred = cnn_model.predict(validation_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
# 获取真实标签，确保是一维数组
y_true = validation_generator.classes

# 保存分类报告和混淆矩阵
report = classification_report(y_true, y_pred_classes, target_names=selected_classes, output_dict=True)
report_df = pd.DataFrame(report).transpose()
report_df.to_csv('classification_report.csv', index=True)

conf_matrix = confusion_matrix(y_true, y_pred_classes)
conf_matrix_df = pd.DataFrame(conf_matrix, index=selected_classes, columns=selected_classes)
conf_matrix_df.to_csv('confusion_matrix.csv', index=True)

# 可视化
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix_df, annot=True, cmap='Blues', fmt="d")
plt.title('Confusion Matrix')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
