import numpy as np
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam

# 1. 数据加载与预处理
# 假设每种天气类型的图片存放在不同的文件夹里，文件夹名称为天气类型的名称
data_dir = 'dataset/train'  # 替换为你的数据集路径
img_height, img_width = 128, 128  # 图片大小调整为一致
batch_size = 32

# 使用ImageDataGenerator进行数据增强和加载
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.3)  # 将数据划分为训练集和验证集

train_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='training'
)

validation_generator = datagen.flow_from_directory(
    data_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation'
)

# 2. 构建CNN模型
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(img_height, img_width, 3)),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D((2, 2)),
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(4, activation='softmax')  # 假设有四种天气类型
])

model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

# 3. 训练模型
history = model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=10
)

# 4. 模型评估
validation_generator.reset()
y_pred = model.predict(validation_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes

# 打印分类报告
class_labels = list(validation_generator.class_indices.keys())
print("CNN Classification Report:\n", classification_report(y_true, y_pred_classes, target_names=class_labels))

# 打印准确率
print("CNN Accuracy: ", accuracy_score(y_true, y_pred_classes))

# 5. 显示每种天气的准确率
conf_matrix = confusion_matrix(y_true, y_pred_classes)
conf_matrix = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]  # 计算每类的准确率
print("Per-class accuracy: ", np.diag(conf_matrix))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_true, y_pred_classes)

# 转换混淆矩阵为百分比形式
conf_matrix_normalized = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]

# 打印每类的准确率
print("Per-class accuracy: ", np.diag(conf_matrix_normalized))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_true, y_pred_classes)

# 转换混淆矩阵为百分比形式
conf_matrix_normalized = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]

# 打印每类的准确率
print("Per-class accuracy: ", np.diag(conf_matrix_normalized))

# 6. 仿真图
# 混淆矩阵可视化
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix_normalized, annot=True, cmap='Blues', xticklabels=class_labels, yticklabels=class_labels, fmt=".2%")
plt.title('Normalized Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()


# 显示训练和验证准确率的变化趋势
plt.figure(figsize=(8, 6))
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

# 显示训练和验证损失的变化趋势
plt.figure(figsize=(8, 6))
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()