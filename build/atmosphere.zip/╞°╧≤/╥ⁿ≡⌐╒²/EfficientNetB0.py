import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.callbacks import ReduceLROnPlateau
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
# 数据集路径
train_dir = 'dataset/train'  # 替换为训练数据集路径
val_dir = 'dataset/test'      # 替换为验证数据集路径

# 参数配置
img_height, img_width = 224, 224   # EfficientNetB0 默认输入尺寸
batch_size = 32
num_classes = 3                    # 类别数量，假设3种天气类型
class_labels = ['Rain', 'Fog', 'Snow']  # 类别标签
# 1. 数据加载与预处理
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    brightness_range=[0.8, 1.2],  # 增加亮度变化
    channel_shift_range=20.0     # 增加颜色通道变化
)

val_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical'
)

val_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False  # 禁止打乱，确保输出顺序一致
)

# 2. 模型构建
base_model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
x = base_model.output
x = GlobalAveragePooling2D()(x)   # 全局平均池化层
x = Dropout(0.5)(x)               # Dropout层，防止过拟合
output = Dense(num_classes, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=output)

# 解冻EfficientNetB0的最后几层
for layer in base_model.layers[-10:]:
    layer.trainable = True

# 3. 编译模型
optimizer = SGD(lr=0.001, momentum=0.9)  # 使用SGD优化器
model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

# 4. 训练模型
epochs = 20  # 增加训练周期
lr_scheduler = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, verbose=1)

history = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=epochs,
    callbacks=[lr_scheduler]
)

# 5. 模型评估
val_loss, val_accuracy = model.evaluate(val_generator)
print(f"Validation Loss: {val_loss:.4f}, Validation Accuracy: {val_accuracy:.4f}")

# 获取预测结果
y_pred = model.predict(val_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = val_generator.classes

# 打印分类报告
print("Classification Report:")
print(classification_report(y_true, y_pred_classes, target_names=class_labels))

# 计算混淆矩阵
conf_matrix = confusion_matrix(y_true, y_pred_classes)
print("Confusion Matrix:")
print(conf_matrix)

# 6. 绘制训练曲线
# 训练和验证的准确率曲线
plt.figure(figsize=(10, 6))
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.title('Training and Validation Accuracy')
plt.legend()
plt.show()

# 训练和验证的损失曲线
plt.figure(figsize=(10, 6))
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training and Validation Loss')
plt.legend()
plt.show()