from data_preprocessing import load_data, preprocess_data
from model_training import (train_logistic_regression, train_svm, train_decision_tree,
                             train_random_forest, train_knn, train_naive_bayes,
                             train_gradient_boosting, train_neural_network, train_mlp, train_pca)
from model_evaluation import evaluate_model
from plot_results import plot_accuracy_comparison
import numpy as np
from sklearn.model_selection import train_test_split
from data_preprocessing import flatten_images

# 加载和预处理数据
image_dir = 'dataset/train'
images, labels = load_data(image_dir)
images, labels = preprocess_data(images, labels)

# 扁平化图像数据（用于传统机器学习模型）
X_flattened = flatten_images(images)

# 划分数据集（针对扁平化数据）
X_train_flat, X_test_flat, y_train, y_test = train_test_split(X_flattened, labels, test_size=0.2, random_state=42)

# 确认数据维度
print("X_train shape (flattened):", X_train_flat.shape)
print("X_test shape (flattened):", X_test_flat.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

# 对于CNN，使用原始图像数据进行划分
X_train, X_test, y_train, y_test = train_test_split(images, labels, test_size=0.2, random_state=42)

# 获取CNN输入形状
input_shape = X_train.shape[1:]  # 原始图像的形状，如 (128, 128, 3)
num_classes = len(np.unique(y_train))

# 训练模型
models = {}
# 使用扁平化数据训练传统机器学习模型
models['Logistic Regression'] = train_logistic_regression(X_train_flat, y_train)
models['SVM'] = train_svm(X_train_flat, y_train)
models['Decision Tree'] = train_decision_tree(X_train_flat, y_train)
models['Random Forest'] = train_random_forest(X_train_flat, y_train)
models['KNN'] = train_knn(X_train_flat, y_train)
models['Naive Bayes'] = train_naive_bayes(X_train_flat, y_train)
models['Gradient Boosting'] = train_gradient_boosting(X_train_flat, y_train)

# MLP模型
models['MLP'] = train_mlp(X_train_flat, y_train)

# PCA降维
X_train_pca, pca = train_pca(X_train_flat, y_train)
models['PCA'] = train_logistic_regression(X_train_pca, y_train)  # 使用PCA降维后的数据训练逻辑回归

# CNN模型（使用原始图像数据）
models['CNN'] = train_neural_network(X_train, y_train, input_shape, num_classes)

# 评估模型
accuracies = []
model_names = []
for name, model in models.items():
    if name == 'PCA':
        X_test_pca = pca.transform(X_test_flat)  # 针对扁平化的测试集应用PCA降维
        accuracy = evaluate_model(model, X_test_pca, y_test)
    elif name == 'CNN':
        accuracy = evaluate_model(model, X_test, y_test)  # 使用原始图像数据评估CNN
    else:
        accuracy = evaluate_model(model, X_test_flat, y_test)  # 使用扁平化数据评估传统模型
    accuracies.append(accuracy)
    model_names.append(name)

# 绘制对比图
plot_accuracy_comparison(model_names, accuracies)