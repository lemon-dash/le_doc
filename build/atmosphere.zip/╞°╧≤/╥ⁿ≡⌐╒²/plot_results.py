import matplotlib.pyplot as plt
import numpy as np  # 添加这行代码
import matplotlib.pyplot as plt
def plot_accuracy_comparison(models, accuracies):
    plt.figure(figsize=(12, 8))
    plt.bar(models, accuracies, color='skyblue')
    plt.xlabel('Machine Learning Methods')
    plt.ylabel('Accuracy')
    plt.title('Weather Recognition Accuracy Comparison')
    plt.xticks(rotation=45)
    plt.ylim(0, 1)  # 如果准确率范围在0到1之间
    plt.tight_layout()
    plt.show()


# 绘制每种天气识别成功率对比图
def plot_weather_accuracy_comparison(models, weather_accuracies_all):
    n_models = len(models)
    index = np.arange(n_models)
    bar_width = 0.2

    plt.figure(figsize=(14, 8))

    # 各种天气类型的识别准确率
    plt.bar(index, [weather_accuracies['rain'] for weather_accuracies in weather_accuracies_all],
            bar_width, label='rain')
    plt.bar(index + bar_width, [weather_accuracies['fog'] for weather_accuracies in weather_accuracies_all],
            bar_width, label='fog')
    plt.bar(index + 2 * bar_width, [weather_accuracies['snow'] for weather_accuracies in weather_accuracies_all],
            bar_width, label='snow')

    plt.xlabel('Models')
    plt.ylabel('Accuracy')
    plt.title('Weather Type Accuracy Comparison Across Models')
    plt.xticks(index + bar_width, models, rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.show()