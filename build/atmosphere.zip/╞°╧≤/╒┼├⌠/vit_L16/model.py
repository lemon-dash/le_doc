import torch
import torch.nn as nn

class ViT(nn.Module):
    def __init__(self, image_size=224, patch_size=16, num_classes=1000, dim=768, depth=12, heads=12, mlp_dim=3072,
                 dropout=0.1, channels=3):
        super(ViT, self).__init__()

        # 初始化 patch_size
        self.patch_size = patch_size  # 保存为实例变量

        assert image_size % patch_size == 0, "Image size must be divisible by patch size"
        num_patches = (image_size // patch_size) ** 2
        patch_dim = 3 * patch_size ** 2  # Assuming 3-channel images (RGB)

        # Patch embedding: 将图像块展平并映射到dim维度
        self.patch_embedding = nn.Linear(patch_dim, dim)

        # 可学习的位置编码
        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))

        # 分类 token（分类标识符）
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))

        # Dropout
        self.dropout = nn.Dropout(dropout)

        # Transformer 模块
        self.transformer = nn.ModuleList([
            TransformerBlock(dim, heads, mlp_dim, dropout) for _ in range(depth)
        ])

        # 分类头
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, num_classes)
        )

    def forward(self, x):
        batch_size, channels, height, width = x.shape

        # 将输入图像划分为patches
        patches = x.unfold(2, self.patch_size, self.patch_size).unfold(3, self.patch_size, self.patch_size)
        patches = patches.contiguous().view(batch_size, -1, self.patch_size ** 2 * channels)

        # 对patches进行线性映射
        x = self.patch_embedding(patches)

        # 添加分类 token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        # 添加位置编码
        x += self.pos_embedding

        # Dropout
        x = self.dropout(x)

        # 通过 Transformer 模块
        for block in self.transformer:
            x = block(x)

        # 取出分类 token 进行分类
        cls_token_final = x[:, 0]

        # 分类头
        x = self.mlp_head(cls_token_final)

        return x


class TransformerBlock(nn.Module):
    def __init__(self, dim, heads, mlp_dim, dropout):
        super(TransformerBlock, self).__init__()
        self.attention = nn.MultiheadAttention(embed_dim=dim, num_heads=heads, dropout=dropout)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, mlp_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        # Multi-head Attention
        attn_output, _ = self.attention(x, x, x)
        x = attn_output + x
        x = self.norm1(x)

        # MLP
        mlp_output = self.mlp(x)
        x = mlp_output + x
        x = self.norm2(x)

        return x


# 测试模型
model = ViT(image_size=224, patch_size=16, num_classes=1000, dim=768, depth=12, heads=12, mlp_dim=3072)

# 随机生成一个 batch 的输入图像，形状为 [batch_size, channels, height, width]
x = torch.randn(8, 3, 224, 224)  # 8 张 RGB 224x224 图像
output = model(x)

#print(output.shape)  # 输出形状应为 (8, 1000)，即 batch_size x num_classes
#模型的输出是一个形状为 [8, 1000] 的张量，表示对于 8 张输入图像，每张图像都有 1000 个类别的预测概率，通常会通过 softmax 函数来确定最终的分类结果。